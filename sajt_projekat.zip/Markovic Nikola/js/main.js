var main = function() {
	$("#icon-menu i").click(function(){
		$("#sidebar").animate({
			right: "0px"
		}, 200)
		$("body").animate({
			right: "285px"
		}, 200);
	});		

	$("#icon-close").click(function(){
		$("#sidebar").animate({
			right: "-285px"
		}, 200)
		$("body").animate({
			right: "0px"
		}, 200);
	});				
};

$(document).ready(main);


//settings for menu

      $(function() {
        $('#menu').on('click', '.nav-item', function(event) {
          event.preventDefault();
          var hash = this.hash;

          $('html, body').animate({
           scrollTop: $(hash).offset().top
          }, 1000, function() {
            window.location.hash = hash;
          });
        });
      });



$(function() {
lightbox.option({
      'resizeDuration': 200,
      'wrapAround': false,
      'fadeDuration': 600,
    })
});
   